package com.ssafy.dao;

import java.sql.Connection;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ssafy.vo.Naver;

@Component
public class NaverDaoImpl implements NaverDao{
	private Connection conn;
	String url = "mybatis.foodMapper.";
	
	@Autowired
	SqlSession session;
	
	public void insert(Naver naver) {
		session.selectOne(url+"insertNaver",naver);
	}

	public Naver selectOne(int num) {
		return session.selectOne(url+"selectOneN",num);
	}
	
	public List<Naver> selectAll() {
		return session.selectList(url+"selectAllN");
	}
	
	public void delete(int num) {
		session.delete(url+"deleteNaver",num);
	}

	@Override
	public void update(Naver naver) {
		session.update(url+"updateNaver",naver);
	}
}
