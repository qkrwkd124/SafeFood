package com.ssafy.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.dao.NaverDao;
import com.ssafy.vo.Customer;
import com.ssafy.vo.Naver;

@RestController
public class JsonController {
	
	@Autowired
	public NaverDao naverDao;
	
	@RequestMapping("list.json")
	public List<Naver> selectAll(){
		return naverDao.selectAll();
	}
	
	@RequestMapping("add.json")
	public void insertN(@RequestBody Naver naver,HttpSession session) {
		System.out.println(naver.getDay());
		Customer c = (Customer)session.getAttribute("c");
		naver.setId(c.getId());
		naver.setWriter(c.getId());
		naverDao.insert(naver);
	}
	
	@RequestMapping("one.json")
	public Naver selectone(HttpSession session){
		return naverDao.selectOne((Integer)session.getAttribute("detailNum"));
	}
	
	@RequestMapping("delete.json")
	public void delete(@RequestBody Naver naver){
		System.out.println(naver.getNum());
		naverDao.delete(naver.getNum());
	}
	@RequestMapping("update.json")
	public void update(@RequestBody Naver naver ,HttpSession session){
		session.setAttribute("naverr",naver);
		System.out.println(naver.getNum());
		System.out.println(naver.getTitle());
		System.out.println(naver.getContents());
	}
	
	@RequestMapping("update2.json")
	public void update2(@RequestBody Naver naver){
		naverDao.update(naver);
	}
}
