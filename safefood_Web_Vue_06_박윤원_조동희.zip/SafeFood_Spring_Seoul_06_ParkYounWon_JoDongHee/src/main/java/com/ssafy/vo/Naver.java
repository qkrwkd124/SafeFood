package com.ssafy.vo;

public class Naver {
	private int num;
	private String title;
	private String writer;
	private String id;
	private String day;
	private String contents;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	
	@Override
	public String toString() {
		return "Naver [num=" + num + ", title=" + title + ", writer=" + writer + ", id=" + id + ", date=" + day
				+ ", contents=" + contents + "]";
	}
}
